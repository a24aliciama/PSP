package ejer6GuessANumberMultiThread.Server;

public class Server {
    public static void main(String[] args) {

    }
}
