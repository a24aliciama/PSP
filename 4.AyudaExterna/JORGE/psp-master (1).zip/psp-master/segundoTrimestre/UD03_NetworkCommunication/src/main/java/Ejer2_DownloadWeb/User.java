package Ejer2_DownloadWeb;

public class User {
    private Integer id;
}
