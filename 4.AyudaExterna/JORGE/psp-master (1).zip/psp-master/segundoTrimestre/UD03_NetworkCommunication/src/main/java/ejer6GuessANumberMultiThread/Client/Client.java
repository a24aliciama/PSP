package ejer6GuessANumberMultiThread.Client;

public class Client {
    public static void main(String[] args) {

    }
}
